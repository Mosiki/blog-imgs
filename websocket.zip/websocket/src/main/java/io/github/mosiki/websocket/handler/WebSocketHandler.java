package io.github.mosiki.websocket.handler;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.AbstractWebSocketHandler;

import java.io.IOException;
import java.util.concurrent.CopyOnWriteArraySet;

@Component
public class WebSocketHandler extends AbstractWebSocketHandler {
    private static CopyOnWriteArraySet<WebSocketSession> webSocketSet = new CopyOnWriteArraySet<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        // 接收到WebSocket会触发
        System.out.println(session.getUri().getQuery());
        webSocketSet.add(session);
        session.sendMessage(new TextMessage("欢迎！！！"));
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus closeStatus) throws Exception {
        // 关闭WebSocket会触发
        System.out.println("关闭WebSocket会触发");
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        exception.printStackTrace();
    }

    /**
     * 广播消息
     */
    public void sendMessage() throws IOException {
        for (WebSocketSession session : webSocketSet) {
            session.sendMessage(new TextMessage("欢迎你来啦！"));
        }
    }
}