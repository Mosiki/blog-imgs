@Service("articleService")
@Transactional
public class ArticleServiceImpl implements ArticleService{
	@Autowired
	private ArticleDao articleDao;
	@Autowired
	private SolrService solrService;

	@Override
	public ByteArrayOutputStream exportArticles(String ids) {
		List<Consensus> articleList = new ArrayList<Consensus>();
		String[] idArr = ids.split(",");
		for (String id : idArr) {
			if(StringUtil.strIsNull(id)){
				break;
			}
			Consensus article = articleDao.findArticleById(id);
			articleList.add(article);
		}
		
		Map<String, Object> root = new HashMap<String, Object>();
		root.put("newsList", newsList);//newsList为新闻对象集合
		String template = "/temp.ftl";  //模板文件的地址
		ByteArrayOutputStream outputStream = WordUtil.process(root, template);
		return outputStream;
	}

}
