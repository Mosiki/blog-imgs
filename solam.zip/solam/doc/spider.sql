/*
 Navicat Premium Data Transfer

 Source Server         : springboot
 Source Server Type    : MySQL
 Source Server Version : 50717
 Source Host           : 192.168.199.197:3306
 Source Schema         : spider

 Target Server Type    : MySQL
 Target Server Version : 50717
 File Encoding         : 65001

 Date: 26/01/2018 20:48:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL COMMENT '结束时间',
  `status` tinyint(11) DEFAULT NULL,
  `name` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `intro` longtext COLLATE utf8mb4_bin,
  `icon` int(11) DEFAULT NULL,
  `author` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for chapter
-- ----------------------------
DROP TABLE IF EXISTS `chapter`;
CREATE TABLE `chapter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `book_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `content_id` bigint(20) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `seq` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68575 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for content
-- ----------------------------
DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68575 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for site
-- ----------------------------
DROP TABLE IF EXISTS `site`;
CREATE TABLE `site` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `site_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '站点名称',
  `site_home` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '站点首页',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for task
-- ----------------------------
DROP TABLE IF EXISTS `task`;
CREATE TABLE `task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `run_state` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '运行状态',
  `site_id` bigint(20) DEFAULT NULL COMMENT '站点Id',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `status` tinyint(4) DEFAULT NULL,
  `task_name` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '任务名称',
  `task_rule_json` mediumtext CHARACTER SET utf8 COMMENT '任务规则json',
  `sprider_uuid` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '任务启动UUID',
  `run_task` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '需要执行任务:是(1);否(2)',
  `timer_task` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '是否定时任务:是(1);否(2)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=COMPACT;

-- ----------------------------
-- Table structure for third_book
-- ----------------------------
DROP TABLE IF EXISTS `third_book`;
CREATE TABLE `third_book` (
  `site_id` bigint(20) NOT NULL COMMENT '站点id',
  `site_book_id` bigint(20) NOT NULL COMMENT '站点BookId',
  `book_id` bigint(20) DEFAULT NULL COMMENT 'bookId',
  `create_time` datetime DEFAULT NULL,
  `last_number` int(11) DEFAULT '0',
  PRIMARY KEY (`site_id`,`site_book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
INSERT INTO `spider`.`site`(`id`, `create_time`, `status`, `site_name`, `site_home`) VALUES (3, '2017-12-24 16:40:05', 0, '爱上小说网', 'https://www.aszw.org/');
INSERT INTO `spider`.`task`(`id`, `create_time`, `end_time`, `run_state`, `site_id`, `start_time`, `status`, `task_name`, `task_rule_json`, `sprider_uuid`, `run_task`, `timer_task`) VALUES (3, '2017-12-24 16:40:19', '2017-12-27 22:01:21', 'Stopped', 3, '2017-12-27 20:52:56', 0, '爱上小说网', '{\"rule\":{\"bookRule\":\"https://www.aszw.org/book/\\\\d+/\\\\d+/\", \"bookXpath\":\"//*/a/@href\", \"chapterXpath\":\"//*[@id=\'at\']/tbody/tr/td/a/@href\", \"chapterRule\":\"\\\\d+.html\",\"bookIdRule\":\"/\\\\d+/(\\\\d+).*\",\"bookInfoRule\":[{\"name\":\"name\",\"reg\":\"\",\"value\":\"//*/div[@class=\'btitle\']/h1/text()\"},{\"name\":\"intro\",\"reg\":\"\",\"value\":\"//*[@id=\'a_main\']/div[2]/dl/div/div[1]/div[1]/div[2]/div[2]/text()\"},{\"name\":\"author\",\"reg\":\"\",\"value\":\"//*/div[@class=\'btitle\']/i[1]/text()\"},{\"name\":\"icon\",\"reg\":\"\",\"value\":\"//*[@id=\'a_main\']/div[2]/dl/div/div[1]/div[1]/div[1]/img/@src\"}],\"chapterContentRule\":[{\"name\":\"name\",\"reg\":\"\",\"value\":\"//*[@id=\'amain\']/div[3]/h1/text()\"},{\"name\":\"content\",\"reg\":\"\",\"value\":\"//*[@id=\'contents\']/text()\"}]},\"site\":{\"domain\":\"https://www.aszw.org/\",\"retry\":3,\"sleepTime\":100,\"timeOutTime\":999999,\"userAgent\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.65 Safari/537.31\"},\"spider\":{\"pipeline\":[],\"processer\":\"novelPageProcess\",\"siteid\":2,\"startUrl\":\"https://www.aszw.org/\",\"thread\":60}}', '1dea6491b4224d18860206dbc69c5aaf', '1', '1');
