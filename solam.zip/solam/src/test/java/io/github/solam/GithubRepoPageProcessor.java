package io.github.solam;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class GithubRepoPageProcessor implements PageProcessor {

    private Site site = Site.me().setRetryTimes(3).setSleepTime(1000).setTimeOut(10000);

    @Override
    public void process(Page page) {

        // URL为首页，生成的是Book的URL正则;
        String urlRegex = getUrlRule(page);

        // 若URL为Book封面页，生成的是Chapter的URL正则
        String s = page.getHtml().xpath("//*/a/@href").regex(urlRegex).get();
        System.out.println(s);
    }

    private String getUrlRule(Page page) {
        // 获取当前页面所有的链接URL
        List<String> list = page.getHtml().xpath("//*/a/@href").all();

        // 得到当前页面数量最多的URL的正则规则
        List<String> list2 = list.stream().map(e -> e.replaceAll("\\d+", "\\\\d+"))
                .collect(Collectors.toList());

        HashMap<String, Integer> map = new HashMap<>();
        for (String item : list2) {
            Integer value = map.get(item);
            map.put(item, (value == null) ? 1 : value + 1);
        }

        // 升序比较器
        Comparator<Map.Entry<String, Integer>> valueComparator = new Comparator<Map.Entry<String,Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> o1,
                               Map.Entry<String, Integer> o2) {
                return o2.getValue()-o1.getValue();
            }
        };

        // map转换成list进行排序
        List<Map.Entry<String, Integer>> list3 = new ArrayList<Map.Entry<String,Integer>>(map.entrySet());
        // 排序
        Collections.sort(list3,valueComparator);
        // 所有作品地址。
//        List<String> list4 = page.getHtml().xpath("//*/a/@href").regex(list3.get(0).getKey()).all();
//        list4.forEach(e -> System.out.println(e));
        // 相对URL正则
        return list3.get(0).getKey();
    }

    @Override
    public Site getSite() {
        return site;
    }

    public static void main(String[] args) {
        Spider.create(new GithubRepoPageProcessor())
                .addUrl("http://www.wenxuemi.com/")
                .thread(5).run();
    }
}