package io.github.solam.repository;

import io.github.solam.domain.Chapter;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ChapterRepositoryTest {

    @Resource
    private ChapterRepository chapterRepository;

    @Test
    public void findNextChapter() throws Exception {
        PageRequest request = new PageRequest(1, 1, new Sort(Sort.Direction.ASC, "seq"));

        Page<Chapter> nextChapter = chapterRepository.findNextChapter(20L, 0, request);
        System.out.println(nextChapter);
    }

}