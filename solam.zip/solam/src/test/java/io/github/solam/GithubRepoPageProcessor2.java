package io.github.solam;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.selector.Selectable;

import java.util.*;
import java.util.stream.Collectors;

public class GithubRepoPageProcessor2 implements PageProcessor {

    private Site site = Site.me().setRetryTimes(3).setSleepTime(1000).setTimeOut(10000);

    @Override
    public void process(Page page) {

        Selectable selectable = page.getHtml().links();
        List<String> links = selectable.regex("http://www\\.zhuishushenqi\\.com/book/(\\w+)", 1).all();
//        links.forEach(e -> System.out.println(e));

        List<String> all = selectable.regex("http://www\\.zhuishushenqi\\.com/category[^\\s]+page=[2-5]").all();
        all.forEach(e -> System.out.println(e));

    }

    @Override
    public Site getSite() {
        return site;
    }

    public static void main(String[] args) {

        Spider.create(new GithubRepoPageProcessor2()).addUrl("http://www.zhuishushenqi.com/category?gender=male&type=hot&major=1").thread(5).run();
    }
}