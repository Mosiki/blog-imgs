package io.github.solam.util;

import org.junit.Test;

import static org.junit.Assert.*;

public class WordUtilTest {

    @Test
    public void addP() throws Exception {


    }

}