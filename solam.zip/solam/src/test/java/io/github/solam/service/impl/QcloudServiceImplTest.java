package io.github.solam.service.impl;

import io.github.solam.service.QcloudService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class QcloudServiceImplTest {

    @Resource
    private QcloudService qcloudService;

    @Test
    public void uploadFile() throws Exception {
        System.out.println(qcloudService.uploadFile("/a.txt", "hello world"));
    }

    @Test
    public void uploadUrlImage() throws Exception {

        qcloudService.uploadUrlImage("/b.png", "http://ojt4b2cr5.bkt.clouddn.com/20171206151256895451444.png");
    }

    @Test
    public void downloadFile() throws Exception {
        System.out.println(qcloudService.downloadFile("/books/content/1"));
    }

}