package io.github.solam;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import netscape.javascript.JSObject;

public class Te {


    public static void main(String[] args) {
        String json = "{\"rule\":{\"bookRule\":\"https://www.aszw.org/book/\\\\d+/\\\\d+/\", \"bookXpath\":\"//*/a/@href\", \"chapterXpath\":\"//*[@id='at']/tbody/tr/td/a/@href\", \"chapterRule\":\"\\\\d+.html\",\"bookIdRule\":\"/\\\\d+/(\\\\d+).*\",\"bookInfoRule\":[{\"name\":\"name\",\"reg\":\"\",\"value\":\"//*/div[@class='btitle']/h1/text()\"},{\"name\":\"intro\",\"reg\":\"\",\"value\":\"//*[@id='a_main']/div[2]/dl/div/div[1]/div[1]/div[2]/div[2]/text()\"},{\"name\":\"author\",\"reg\":\"\",\"value\":\"//*/div[@class='btitle']/i[1]/text()\"},{\"name\":\"icon\",\"reg\":\"\",\"value\":\"//*[@id='a_main']/div[2]/dl/div/div[1]/div[1]/div[1]/img/@src\"}],\"chapterContentRule\":[{\"name\":\"name\",\"reg\":\"\",\"value\":\"//*[@id='amain']/div[3]/h1/text()\"},{\"name\":\"content\",\"reg\":\"\",\"value\":\"//*[@id='contents']/text()\"}]},\"site\":{\"domain\":\"https://www.aszw.org/\",\"retry\":3,\"sleepTime\":100,\"timeOutTime\":999999,\"userAgent\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.65 Safari/537.31\"},\"spider\":{\"pipeline\":[\"aaa\",\"bbb\"],\"processer\":\"novelPageProcess\",\"siteid\":2,\"startUrl\":\"https://www.aszw.org/\",\"thread\":60}}";
        JSONObject jsonObject = JSONObject.parseObject(json);
        JSONObject sipderJson = jsonObject.getJSONObject("spider");
        int thread = sipderJson.getIntValue("thread");
        JSONArray pipelineJson = sipderJson.getJSONArray("pipeline");
        String s = pipelineJson.getString(1);
        System.out.println(s);
        System.out.println(thread);
    }

}
