package io.github.solam.spider;

import com.alibaba.fastjson.JSONObject;
import io.github.solam.spider.process.SitePageProcess;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest
public class WebMagicServiceTest {

//    @Resource
//    private SitePageProcess sitePageProcess;
//
//    @Test
//    public void generateRegex() throws Exception {
//
//        JSONObject params = new JSONObject();
//        params.put("homeUrl", "http://www.wenxuemi.com/");
//        params.put("bookUrl", "http://www.wenxuemi.com/files/article/html/22/22768/");
//        params.put("id", 1L);
//
//        sitePageProcess.generateRegex(params);
//    }

}