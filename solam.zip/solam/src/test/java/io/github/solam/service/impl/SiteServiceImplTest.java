package io.github.solam.service.impl;

import io.github.solam.domain.Site;
import io.github.solam.service.SiteService;
import io.github.solam.util.constants.Constants;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.Date;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SiteServiceImplTest {

    @Resource
    private SiteService siteService;

    @Test
    public void findList() throws Exception {
        PageRequest request = new PageRequest(1, 10);

        Page<Site> list = siteService.findList(request);
        System.out.println(list.getTotalPages());
    }

    @Test
    public void createSite() throws Exception {
        Site site = new Site();
        site.setSiteHome("http://www.biquge.tw");
        site.setSiteName("笔趣阁");
        site.setCreateTime(new Date());
        site.setStatus(Constants.STATUS_NORMAL);
        Site result = siteService.createSite(site);
        Assert.assertNotNull(result);
    }

    @Test
    public void findOne() throws Exception {
        Site result = siteService.findOne(1L);
        Assert.assertNotNull(result);
    }

    @Test
    public void updateSite() throws Exception {
        Site site = siteService.findOne(1l);
        site.setStatus(Constants.STATUS_DELETE);
        Site result = siteService.updateSite(site);
        Assert.assertNotNull(result);
    }

    @Test
    public void delSite() throws Exception {

    }

}