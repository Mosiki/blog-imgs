package io.github.solam.service.impl;

import io.github.solam.dto.TaskDTO;
import io.github.solam.service.TaskService;
import io.github.solam.util.constants.Constants;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class TaskServiceImplTest {

    @Resource
    private TaskService taskService;

    @Test
    public void findAll() throws Exception {
        List<TaskDTO> all = taskService.findAll();
        Assert.assertNotEquals(1, all.size());
    }

    @Test
    public void findOne() throws Exception {
        TaskDTO one = taskService.findOne(33L);
        Assert.assertNotNull(one);
    }

    @Test
    public void update() throws Exception {
        TaskDTO task = new TaskDTO();
        task.setId(1L);
        task.setSiteId(3L);
        task.setCreateTime(new Date());
        task.setEndTime(new Date());
        task.setRunTask(1);
        task.setRunState("run");
        task.setSpiderUUID("a001");
        task.setStartTime(new Date());
        task.setStatus(Constants.STATUS_NORMAL);
        task.setTaskName("测试1");
        task.setTaskRuleJson("{\"a\":1}");
        task.setTimerTask(1);
        TaskDTO taskDTO = taskService.updateTask(task);
        Assert.assertTrue("相等", taskDTO.getSiteId() == 3L);
    }

    @Test
    public void name() throws Exception {
        String url = "https://www.xs.la/78_78031/4003531.html";

        String rule = "\\d+_(\\d+)";
        Matcher matcher = Pattern.compile(rule).matcher(url);
        if (matcher.find()){
            System.out.println(matcher.group(1));
        }
    }
}