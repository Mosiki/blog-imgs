package io.github.solam.service.impl;

import io.github.solam.service.MemcacheService;
import net.spy.memcached.AddrUtil;
import net.spy.memcached.ConnectionFactoryBuilder;
import net.spy.memcached.MemcachedClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

//@Service
public class MemcacheServiceImpl implements MemcacheService{


    /*@Value()

    private MemcachedClient cache = null;

    // 参考  https://help.aliyun.com/document_detail/48354.html?spm=5176.doc55595.6.560.PYCypg
    @PostConstruct
    public void init() {
        cache = new MemcachedClient(new ConnectionFactoryBuilder().setProtocol(ConnectionFactoryBuilder.Protocol.BINARY).build(),
                AddrUtil.getAddresses(host + ":" + port));
    }*/


}
