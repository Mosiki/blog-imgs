package io.github.solam.domain;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "site")
@Data
public class Site {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "site_name",columnDefinition = "NVARCHAR(100) COMMENT '站点名称'")
    private String siteName;

    @Column(name = "site_home",columnDefinition = "NVARCHAR(100) COMMENT '站点首页'")
    private String siteHome;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "status")
    private Byte status;
}
