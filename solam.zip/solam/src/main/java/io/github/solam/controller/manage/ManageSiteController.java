package io.github.solam.controller.manage;

import io.github.solam.domain.Site;
import io.github.solam.service.SiteService;
import io.github.solam.util.ResultUtils;
import io.github.solam.vo.ResultVO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.Map;

@Controller
@RequestMapping(value = "/site")
public class ManageSiteController {

    @Resource
    private SiteService siteService;

    @GetMapping(value = "/list")
    public ModelAndView list(@RequestParam(value = "page", defaultValue = "1")Integer page,
                             @RequestParam(value = "size", defaultValue = "10")Integer size, Map<String, Object> map) {
        PageRequest request = new PageRequest(page-1, size);
        Page<Site> pages = siteService.findList(request);
        map.put("pages", pages);
        return new ModelAndView("/manage/site/list", map);
    }

    @GetMapping(value = "/add")
    public ModelAndView add() {
        return new ModelAndView("/manage/site/add");
    }

    @PostMapping(value = "/add")
    @ResponseBody
    public ResultVO add(Site site, Map<String, Object> map) {
        Site result = siteService.createSite(site);
        return ResultUtils.succss(result);
    }

    @PostMapping(value = "/del")
    @ResponseBody
    public ResultVO del(Long id) {
        Site result = siteService.delSite(id);
        return ResultUtils.succss(result);
    }

    @GetMapping(value = "/edit")
    public ModelAndView edit(Long id, Map<String, Object> map) {

        Site result = siteService.findOne(id);
        map.put("result", result);
        return new ModelAndView("/manage/site/edit", map);
    }

    @PostMapping(value = "/edit")
    @ResponseBody
    public ResultVO edit(Site site) {
        site = siteService.updateSite(site);
        return ResultUtils.succss(site);
    }

}
