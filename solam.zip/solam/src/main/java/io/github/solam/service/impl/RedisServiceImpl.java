/*
package io.github.solam.service.impl;

import io.github.solam.service.RedisService;
import io.github.solam.util.constants.CacheConstants;
import io.github.solam.util.emums.JedisPrefixTypeEnum;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Data
@Slf4j
@Service
public class RedisServiceImpl implements RedisService{

    @Autowired
    private StringRedisTemplate redisTemplate;

    private String getKey(JedisPrefixTypeEnum type, String key) {
        return type.getValue() + CacheConstants.SEPARATOR + key;
    }

    @Override
    public void set(JedisPrefixTypeEnum type, String key, String value, long seconds) {
        redisTemplate.opsForValue().set(this.getKey(type, key), value, seconds);
    }

    @Override
    public String get(JedisPrefixTypeEnum type, String key) {
        return redisTemplate.opsForValue().get(this.getKey(type, key));
    }

}
*/
