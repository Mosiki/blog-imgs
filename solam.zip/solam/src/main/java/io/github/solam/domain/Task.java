package io.github.solam.domain;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "task")
@Data
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "site_id",columnDefinition = "bigint COMMENT '站点Id'")
    private Long siteId;

    @Column(name = "task_name",columnDefinition = "NVARCHAR(100) COMMENT '任务名称'")
    private String taskName;

    @Column(name = "run_state",columnDefinition = "NVARCHAR(20) COMMENT '运行状态:running(运行中);stop(已结束)'")
    private String runState;

    @Column(name = "timer_task",columnDefinition = "NVARCHAR(20) COMMENT '是否定时任务:是(1);否(2)'")
    private Integer timerTask;

    @Column(name = "run_task",columnDefinition = "NVARCHAR(20) COMMENT '需要执行任务:是(1);否(2)'")
    private Integer runTask;

    @Column(name = "start_time",columnDefinition = "datetime COMMENT '开始时间'")
    private Date startTime;

    @Column(name = "end_time",columnDefinition = "datetime COMMENT '结束时间'")
    private Date endTime;

    @Column(name = "task_rule_json",columnDefinition = "MEDIUMTEXT COMMENT '任务规则json'")
    private String taskRuleJson;

    @Column(name = "sprider_uuid",columnDefinition = "NVARCHAR(50) COMMENT '任务启动UUID'")
    private String spiderUUID;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "status")
    private Byte status;
}
