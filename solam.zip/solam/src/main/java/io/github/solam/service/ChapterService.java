package io.github.solam.service;

import io.github.solam.domain.Chapter;
import io.github.solam.domain.Content;
import io.github.solam.dto.ChapterDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ChapterService {

    Chapter add(Chapter chapter);

    Content add(String content);

    Page<Chapter> findList(Pageable pageable, Long bookId);

    Chapter findOne(Long chapterId);

    Content getContent(Long contentId);

    ChapterDTO findFirstChapter(Long bookId);

    ChapterDTO getChapter(Long chapterId);

    Chapter getNextChapterId(Long chapterId);
}
