package io.github.solam.service;

import io.github.solam.dto.TaskDTO;

import java.util.List;

public interface TaskService {

    TaskDTO createTask(TaskDTO taskDTO);

    List<TaskDTO> findAll();

    TaskDTO findOne(Long taskId);

    TaskDTO updateTask(TaskDTO taskDTO);

    TaskDTO delTask(Long taskDTO);

    TaskDTO update(TaskDTO taskDTO);
}
