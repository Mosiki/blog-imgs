package io.github.solam.spider.pipe;

import com.alibaba.fastjson.JSONObject;
import io.github.solam.domain.Site;
import io.github.solam.dto.TaskDTO;
import io.github.solam.service.SiteService;
import io.github.solam.service.TaskService;
import io.github.solam.spider.WebMagicService;
import io.github.solam.spider.configmodel.*;
import io.github.solam.util.EnumUtils;
import io.github.solam.util.emums.ApiTypeEnum;
import org.springframework.stereotype.Service;
import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.Pipeline;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Map;

@Service
public class SitePipeline implements Pipeline {

    @Resource
    private TaskService taskService;
    @Resource
    private WebMagicService webMagicService;
    @Resource
    private SiteService siteService;

    @Override
    public void process(ResultItems resultItems, Task task) {

        if (!resultItems.isSkip()) {
            Map<String, Object> all = resultItems.getAll();

            Integer type = (Integer) all.get("type");
            Long taskId = (Long) all.get("id");
            TaskDTO taskDTO = taskService.findOne(taskId);

            String ruleJson = taskDTO.getTaskRuleJson();
            WebMagicConfig config = "".equals(ruleJson) || ruleJson == null ? generateDefaultRule(taskDTO) : JSONObject.parseObject(ruleJson, WebMagicConfig.class);
            switch (EnumUtils.getEnumByCode(type, ApiTypeEnum.class)) {
                case BOOK_INFO: {
                    String bookInfoRule = (String) all.get("bookInfoRule");
                    RuleMatchConfig rule = config.getRule();
                    rule.setBookRule(bookInfoRule);
                    taskDTO.setTaskRuleJson(JSONObject.toJSONString(config));
                    taskService.update(taskDTO);
                }
                break;
                case CHAPTER_CONTENT: {
                    String chapterRule = (String) all.get("chapterRule");
                    config.getRule().setChapterRule(chapterRule);
                    taskDTO.setTaskRuleJson(JSONObject.toJSONString(config));
                    taskService.update(taskDTO);
                }
                    break;
                default:
                    break;
            }
        }
    }

    private WebMagicConfig generateDefaultRule(TaskDTO taskDTO) {

        SpiderConfig spiderConfig = new SpiderConfig();
        spiderConfig.setPipeline(Arrays.asList("novelPipeline"));
        spiderConfig.setSiteid(taskDTO.getSiteId());
        spiderConfig.setProcesser("novelPageProcess");
        Site site = siteService.findOne(taskDTO.getSiteId());
        spiderConfig.setStartUrl(site.getSiteHome());
        spiderConfig.setThread(1);

        SiteConfig siteConfig = new SiteConfig();
        siteConfig.setDomain(site.getSiteHome());
        siteConfig.setRetry(3);
        siteConfig.setSleepTime(222);
        siteConfig.setTimeOutTime(9999);
        siteConfig.setUserAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.65 Safari/537.31");

        RuleMatchConfig ruleMatchConfig = new RuleMatchConfig();
        WebMagicConfig config = new WebMagicConfig();
        config.setSpider(spiderConfig);
        config.setSite(siteConfig);
        config.setRule(ruleMatchConfig);
        return config;
    }
}
