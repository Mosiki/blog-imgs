package io.github.solam.domain;

import lombok.Data;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "third_book")
@Data
public class ThirdBook {

    @EmbeddedId
    private ThirdBookPK id;

    private Long bookId;

    private Date createTime;

    private Integer lastNumber;
}
