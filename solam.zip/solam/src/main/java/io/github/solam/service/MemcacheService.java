package io.github.solam.service;

public interface MemcacheService {
}
