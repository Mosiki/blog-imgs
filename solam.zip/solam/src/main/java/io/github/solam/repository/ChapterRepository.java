package io.github.solam.repository;

import io.github.solam.domain.Chapter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ChapterRepository extends JpaRepository<Chapter, Long>{

    Page<Chapter> findByBookId(Long bookId, Pageable pageable);

    @Query(nativeQuery=false, value = "select chapter from Chapter chapter where bookId=?1 and seq>?2")
    Page<Chapter> findNextChapter(Long bookId, Integer seq, Pageable pageable);
}
