package io.github.solam.util.constants;

public interface CacheConstants {

    String SEPARATOR = "#";

    // 验证码发送频率  2分钟
    long SEND_FREQUENCY = 1000 * 60 * 2;

    // 验证码有效期 10 分钟
    long CODE_TIME = 1000 * 60 * 10;

}
