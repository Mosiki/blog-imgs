package io.github.solam.domain;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "content")
public class Content {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "content",columnDefinition = "MEDIUMTEXT COMMENT '章节内容'")
    private String content;
}
