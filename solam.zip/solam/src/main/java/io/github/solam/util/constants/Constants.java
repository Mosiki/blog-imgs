package io.github.solam.util.constants;

public interface Constants {

    Byte STATUS_DELETE = -1;
    Byte STATUS_NORMAL = 0;

    String CONTENT_PREFIX = "/books/content/";
    String ICON_PROFIX = "/books/icon/";
    String QCLOUD_DOMAIN = "http://spider-1252763937.cosbj.myqcloud.com";


}
