package io.github.solam.service.impl;

import io.github.solam.converter.Task2TaskDTOConverter;
import io.github.solam.domain.Task;
import io.github.solam.dto.TaskDTO;
import io.github.solam.exception.SolamException;
import io.github.solam.repository.TaskRepository;
import io.github.solam.service.TaskService;
import io.github.solam.util.RandomUtil;
import io.github.solam.util.constants.Constants;
import io.github.solam.util.emums.ResultEnum;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import us.codecraft.webmagic.Spider;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class TaskServiceImpl implements TaskService {

    @Resource
    private TaskRepository taskRepository;

    @Override
    public TaskDTO createTask(TaskDTO taskDTO) {
        Task task = new Task();
        taskDTO.setCreateTime(new Date());
        taskDTO.setSpiderUUID(RandomUtil.getUUID());
        taskDTO.setRunState(Spider.Status.Stopped.name());
        taskDTO.setStatus(Constants.STATUS_NORMAL);
        BeanUtils.copyProperties(taskDTO, task);
        task = taskRepository.save(task);
        return Task2TaskDTOConverter.conver(task);
    }

    @Override
    public TaskDTO delTask(Long taskId) {
        Task task = new Task();
        TaskDTO taskDTO = this.findOne(taskId);
        if (Constants.STATUS_DELETE.equals(taskDTO.getStatus())) {
            throw new SolamException(ResultEnum.TASK_STATUS_ERROR);
        }
        taskDTO.setStatus(Constants.STATUS_DELETE);
        BeanUtils.copyProperties(taskDTO, task);
        task = taskRepository.save(task);
        return Task2TaskDTOConverter.conver(task);
    }

    @Override
    public List<TaskDTO> findAll() {

        List<Task> taskList = taskRepository.findTaskByStatus(Constants.STATUS_NORMAL);
        List<TaskDTO> dtoList = Task2TaskDTOConverter.conver(taskList);
        return dtoList;
    }

    @Override
    public TaskDTO findOne(Long taskId) {
        Task task = taskRepository.findOne(taskId);
        return Task2TaskDTOConverter.conver(task);
    }

    @Override
    public TaskDTO updateTask(TaskDTO taskDTO) {
        Task task = taskRepository.findOne(taskDTO.getId());

        if (task == null) {
            throw new SolamException(ResultEnum.TASK_NOT_EXIST);
        }

        task.setSiteId(taskDTO.getSiteId());
        task.setTaskName(taskDTO.getTaskName());
        task.setTimerTask(taskDTO.getTimerTask());
        task.setRunTask(taskDTO.getRunTask());
        task.setTaskRuleJson(taskDTO.getTaskRuleJson());
        Task result = taskRepository.save(task);
        return Task2TaskDTOConverter.conver(result);
    }

    @Override
    public TaskDTO update(TaskDTO taskDTO) {
        Task task = taskRepository.findOne(taskDTO.getId());

        if (task == null) {
            throw new SolamException(ResultEnum.TASK_NOT_EXIST);
        }

        BeanUtils.copyProperties(taskDTO, task);
        Task result = taskRepository.save(task);
        return Task2TaskDTOConverter.conver(result);
    }
}
