package io.github.solam.util.emums;

import lombok.Getter;

@Getter
public enum ApiTypeEnum implements CodeEnum{

    BOOK_INFO(1),
    CHAPTER_CONTENT(2),

    ;

    private Integer code;

    ApiTypeEnum(Integer code) {
        this.code = code;
    }
}
