package io.github.solam.repository;

import io.github.solam.domain.ThirdBook;
import io.github.solam.domain.ThirdBookPK;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ThirdBookRepository extends JpaRepository<ThirdBook, ThirdBookPK>{
}
