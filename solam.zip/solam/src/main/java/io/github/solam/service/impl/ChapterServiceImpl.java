package io.github.solam.service.impl;

import io.github.solam.converter.Chapter2ChapterDTOConverter;
import io.github.solam.domain.Chapter;
import io.github.solam.domain.Content;
import io.github.solam.dto.ChapterDTO;
import io.github.solam.repository.ChapterRepository;
import io.github.solam.repository.ContentRepository;
import io.github.solam.service.ChapterService;
import io.github.solam.service.QcloudService;
import io.github.solam.util.constants.Constants;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

@Service
public class ChapterServiceImpl implements ChapterService{

    @Resource
    private ChapterRepository chapterRepository;
    @Resource
    private ContentRepository contentRepository;
    @Resource
    private QcloudService qcloudService;

    @Override
    public Chapter add(Chapter chapter) {
        chapter.setCreateTime(new Date());
        chapter.setStatus(Constants.STATUS_NORMAL);
        return chapterRepository.save(chapter);
    }

    @Override
    public Content add(String value) {
        Content content = new Content();
//        content.setContent();
        content = contentRepository.save(content);

        this.addContent2Cache(content.getId(), value);
        return content;
    }

    @Override
    public Page<Chapter> findList(Pageable pageable, Long bookId) {
        return chapterRepository.findByBookId(bookId, pageable);
    }

    private void addContent2Cache(Long contentId, String value) {
        qcloudService.uploadFile(Constants.CONTENT_PREFIX + contentId, value);
    }

    @Override
    public Chapter findOne(Long chapterId) {
        return chapterRepository.findOne(chapterId);
    }

    @Override
    public Content getContent(Long contentId) {
        Content content = new Content();
        content.setId(contentId);

        String contentStr = qcloudService.downloadFile(Constants.CONTENT_PREFIX + contentId);
        content.setContent(contentStr);
        return content;
    }

    @Override
    public ChapterDTO findFirstChapter(Long bookId) {

        PageRequest request = new PageRequest(0, 1, new Sort(Sort.Direction.ASC, "seq"));
        Page<Chapter> chapters = findList(request, bookId);
        Chapter chapter = chapters.getContent().get(0);
        ChapterDTO chapterDTO = Chapter2ChapterDTOConverter.conver(chapter);
        chapterDTO.setContent(this.getContent(chapter.getContentId()).getContent());
        return chapterDTO;
    }

    @Override
    public ChapterDTO getChapter(Long chapterId) {
        Chapter chapter = this.findOne(chapterId);
        ChapterDTO chapterDTO = Chapter2ChapterDTOConverter.conver(chapter);

        chapterDTO.setContent(this.getContent(chapter.getContentId()).getContent());
        return chapterDTO;
    }

    @Override
    public Chapter getNextChapterId(Long chapterId) {
        Chapter chapter = chapterRepository.findOne(chapterId);
        PageRequest request = new PageRequest(0, 1, new Sort(Sort.Direction.ASC, "seq"));
        Page<Chapter> nextChapter = chapterRepository.findNextChapter(chapter.getBookId(), chapter.getSeq(), request);
        return nextChapter.getContent().get(0);
    }
}
