package io.github.solam.service;

public interface MobileService {

    void sendCode(String phone);
}
