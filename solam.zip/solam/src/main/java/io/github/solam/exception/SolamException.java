package io.github.solam.exception;

import io.github.solam.util.emums.ResultEnum;
import lombok.Getter;

@Getter
public class SolamException extends RuntimeException{

    private Integer code;

    public SolamException(ResultEnum resultEnum) {
        super(resultEnum.getMessage());
        this.code = resultEnum.getCode();
    }

    public SolamException(Integer code, String message) {
        super(message);
        this.code = code;
    }
}
