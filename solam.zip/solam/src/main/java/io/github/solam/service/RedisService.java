package io.github.solam.service;

import io.github.solam.util.emums.JedisPrefixTypeEnum;

public interface RedisService {

    void set(JedisPrefixTypeEnum type, String key, String value, long seconds);

    String get(JedisPrefixTypeEnum type, String key);
}
