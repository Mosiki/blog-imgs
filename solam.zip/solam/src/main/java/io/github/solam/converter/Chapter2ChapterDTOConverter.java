package io.github.solam.converter;

import io.github.solam.domain.Chapter;
import io.github.solam.dto.ChapterDTO;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.stream.Collectors;

public class Chapter2ChapterDTOConverter {

    public static ChapterDTO conver(Chapter chapter) {
        ChapterDTO dto = new ChapterDTO();
        BeanUtils.copyProperties(chapter, dto);
        return dto;
    }

    public static List<ChapterDTO> conver(List<Chapter> list) {
        List<ChapterDTO> collect = list.stream().map(e -> conver(e)).collect(Collectors.toList());
        return collect;
    }

    public static Chapter conver(ChapterDTO chapterDTO) {
        Chapter chapter = new Chapter();
        BeanUtils.copyProperties(chapterDTO, chapter);
        return chapter;
    }
}
