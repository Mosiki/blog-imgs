package io.github.solam.service;

import io.github.solam.domain.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface BookService {

    Book add(Book book);

    Book update(Book book);

    Page<Book> findList(Pageable pageable);

    List<Book> findAll();

    Book findOne(Long id);

    void delSite(Long id);
}
