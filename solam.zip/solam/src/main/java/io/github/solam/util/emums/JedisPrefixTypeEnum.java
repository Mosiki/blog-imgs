package io.github.solam.util.emums;
import lombok.Getter;

@Getter
public enum JedisPrefixTypeEnum {

    MOBILE_CODE("mobile_code"),
    ;


    private String value;

    JedisPrefixTypeEnum(String value) {
        this.value = value;
    }
}
