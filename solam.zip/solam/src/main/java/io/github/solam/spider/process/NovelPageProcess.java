package io.github.solam.spider.process;

import io.github.solam.domain.*;
import io.github.solam.exception.SolamException;
import io.github.solam.service.*;
import io.github.solam.spider.configmodel.DetailRuleConfig;
import io.github.solam.spider.configmodel.RuleMatchConfig;
import io.github.solam.spider.configmodel.WebMagicConfig;
import io.github.solam.util.constants.Constants;
import io.github.solam.util.emums.ApiTypeEnum;
import org.springframework.stereotype.Service;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Request;
import us.codecraft.webmagic.selector.Html;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class NovelPageProcess extends AbstractPageProcess {

    @Resource
    private BookService bookService;
    @Resource
    private ChapterService chapterService;
    @Resource
    private QcloudService qcloudService;
    @Resource
    private ThirdBookService thirdBookService;

    @Override
    public void init(WebMagicConfig config) {
        super.setConfig(config);
    }

    @Override
    public void process(Page page) {

        // 从起始页进来
        WebMagicConfig config = super.getConfig();
        String pageUrl = page.getUrl().get();
        RuleMatchConfig rule = config.getRule();

        if (config.getSpider().getStartUrl().equals(pageUrl)) {
            String bookRule = config.getRule().getBookRule();
            // 添加所有的作品链接
            page.addTargetRequests(page.getHtml().xpath(rule.getBookXpath()).regex(bookRule).all());
            page.getResultItems().setSkip(true);
            return;
        }

        Html html = page.getHtml();

        // 从内容页进来,先于book的url进行判断
        Matcher matcher = Pattern.compile(rule.getChapterRule()).matcher(pageUrl);
        if (matcher.find()) {
            // 抓取内容信息
            Map<String, String> params = new HashMap<>();
            rule.getChapterContentRule().forEach(e -> params.put(e.getName(), html.xpath(e.getValue()).get()));

//            Long siteBookId = getBookId(pageUrl, rule.getBookIdRule());
            Map<String, Object> extras = page.getRequest().getExtras();
            Content content = chapterService.add(params.get("content"));
            Chapter chapter = new Chapter();
            chapter.setBookId((Long) extras.get("bookId"));
            chapter.setName(params.get("name"));
            chapter.setContentId(content.getId());
            chapter.setSeq((Integer) extras.get("seq"));
            chapterService.add(chapter);
            return;
        }

        // 从book封面页进来
        if (Pattern.compile(rule.getBookRule()).matcher(pageUrl).find()) {
            String chapterRule = rule.getChapterRule();

            //抓取作品详情
            Long siteId = config.getSpider().getSiteid();
            Long siteBookId = getBookId(pageUrl, rule.getBookIdRule());

            ThirdBookPK id = new ThirdBookPK();
            id.setSiteBookId(siteBookId);
            id.setSiteId(siteId);
            ThirdBook thirdBook = thirdBookService.get(id);

            if (thirdBook == null) {
                thirdBook = new ThirdBook();
                thirdBook.setId(id);
                thirdBook = thirdBookService.add(thirdBook);
            }

            Map<String, String> params = new HashMap<>();
            rule.getBookInfoRule().forEach(e -> params.put(e.getName(), html.xpath(e.getValue()).get()));
            Book book = new Book();
            book.setName(params.get("name"));
            book.setAuthor(params.get("author"));
            book.setIntro(params.get("intro"));
            book.setIcon(1);
            Book result = bookService.add(book);
            try {
                qcloudService.uploadUrlImage(Constants.ICON_PROFIX + result.getId(), params.get("icon"));
            } catch (SolamException e) {
                result.setIcon(0);
                bookService.update(result);
            }

            // 构造章节抓取URL
            List<String> list = page.getHtml().xpath(rule.getChapterXpath()).regex(chapterRule).all();

            int seq = 1;
            for (String item : list) {
                Map<String, Object> extras = new HashMap<>();
                extras.put("bookId", result.getId());
                extras.put("seq", seq++);
                Request request = new Request(pageUrl + item);
                request.setExtras(extras);
                page.addTargetRequest(request);
            }

            thirdBook.setLastNumber(seq);
            thirdBook.setBookId(result.getId());
            thirdBookService.update(thirdBook);
            return;
        }

    }

    private Long getBookId(String url, String bookIdRule) {
        Matcher matcher1 = Pattern.compile(bookIdRule).matcher(url);
        String bookId = "";
        if (matcher1.find()){
            bookId = matcher1.group(1);
        }
        return Long.valueOf(bookId);
    }

}
