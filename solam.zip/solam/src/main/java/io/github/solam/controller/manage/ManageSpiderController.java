package io.github.solam.controller.manage;

import com.alibaba.fastjson.JSONObject;
import io.github.solam.domain.Site;
import io.github.solam.dto.TaskDTO;
import io.github.solam.exception.SolamException;
import io.github.solam.service.SiteService;
import io.github.solam.service.TaskService;
import io.github.solam.spider.WebMagicService;
import io.github.solam.spider.process.SitePageProcess;
import io.github.solam.util.ResultUtils;
import io.github.solam.util.emums.ResultEnum;
import io.github.solam.vo.ResultVO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import us.codecraft.webmagic.Spider;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/spider")
public class ManageSpiderController {

    @Resource
    private TaskService taskService;
    @Resource
    private WebMagicService webMagicService;

    @GetMapping(value = "/start")
    @ResponseBody
    public ResultVO start(Long taskId) throws Exception {
        TaskDTO taskDTO = taskService.findOne(taskId);
        if (taskDTO == null) {
            throw new SolamException(ResultEnum.TASK_NOT_EXIST);
        }

        taskDTO.setRunState(Spider.Status.Running.name());
        taskDTO.setStartTime(new Date());

        // 更新Task状态
        taskDTO = taskService.update(taskDTO);
        webMagicService.run(taskDTO, true);

        return ResultUtils.succss(taskDTO);
    }

    @GetMapping(value = "/stop")
    @ResponseBody
    public ResultVO stop(Long taskId) throws Exception {
        TaskDTO taskDTO = taskService.findOne(taskId);
        if (taskDTO == null) {
            throw new SolamException(ResultEnum.TASK_NOT_EXIST);
        }

        // 修改任务状态
        taskDTO.setEndTime(new Date());
        taskDTO.setRunState(Spider.Status.Stopped.name());
        taskDTO = taskService.update(taskDTO);
        taskDTO = webMagicService.stop(taskDTO);

        return ResultUtils.succss(taskDTO);
    }

    @GetMapping(value = "/monitor/list")
    public ModelAndView monitorList(Map<String, Object> map) {

        List<TaskDTO> dtoList = webMagicService.runTaskList();
        map.put("tasks", dtoList);
        return new ModelAndView("/manage/task/monitor_list", map);
    }

}
