package io.github.solam.controller.manage;

import io.github.solam.domain.Book;
import io.github.solam.domain.Chapter;
import io.github.solam.domain.Content;
import io.github.solam.service.BookService;
import io.github.solam.service.ChapterService;
import io.github.solam.util.WordUtil;
import io.github.solam.util.constants.Constants;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.Map;

@Controller
@RequestMapping(value = "/manage/book")
public class ManageBookController {

    @Resource
    private BookService bookService;
    @Resource
    private ChapterService chapterService;

    @GetMapping(value = "/list")
    public ModelAndView list(@RequestParam(value = "page", defaultValue = "1")Integer page,
                             @RequestParam(value = "size", defaultValue = "10")Integer size, Map<String, Object> map) {

        Sort sort = new Sort(Sort.Direction.ASC, "id");
        PageRequest request = new PageRequest(page-1, size, sort);
        Page<Book> pages = bookService.findList(request);
        map.put("pages", pages);
        map.put("currentPage", page);
        return new ModelAndView("/manage/book/list", map);
    }

    @GetMapping(value = "/detail/{bookId}")
    public ModelAndView detail(@PathVariable(name = "bookId") Long bookId,
                               @RequestParam(value = "page", defaultValue = "1")Integer page,
                               @RequestParam(value = "size", defaultValue = "1000")Integer size,
                               Map<String, Object> map) {
        Book book = bookService.findOne(bookId);

        Sort sort = new Sort(Sort.Direction.ASC, "seq");
        PageRequest request = new PageRequest(page-1, size, sort);
        Page<Chapter> pages = chapterService.findList(request, bookId);
        map.put("result", book);
        map.put("pages", pages);
        map.put("imgPrefix", Constants.QCLOUD_DOMAIN + Constants.ICON_PROFIX);
        map.put("currentPage", page);
        return new ModelAndView("/manage/book/detail", map);
    }

    @GetMapping(value = "/chapter/{chapterId}")
    public ModelAndView content(@PathVariable(name = "chapterId") String chapterId,
                               Map<String, Object> map) {

        Chapter chapter = chapterService.findOne(Long.parseLong(chapterId));
        Content content = chapterService.getContent(chapter.getContentId());
        map.put("chapter", chapter);
        map.put("result", WordUtil.addP(content.getContent()));
        return new ModelAndView("/manage/book/chapter", map);
    }

}
