package io.github.solam.util.emums;

public interface CodeEnum {

    Integer getCode();

}
