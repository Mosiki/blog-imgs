package io.github.solam.converter;

import io.github.solam.domain.Book;
import io.github.solam.dto.BookDTO;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.stream.Collectors;

public class Book2BookDTOConverter {

    public static BookDTO conver(Book book) {
        BookDTO dto = new BookDTO();
        BeanUtils.copyProperties(book, dto);
        return dto;
    }

    public static List<BookDTO> conver(List<Book> list) {
        List<BookDTO> collect = list.stream().map(e -> conver(e)).collect(Collectors.toList());
        return collect;
    }

    public static Book conver(BookDTO bookDTO) {
        Book book = new Book();
        BeanUtils.copyProperties(bookDTO, book);
        return book;
    }
}
