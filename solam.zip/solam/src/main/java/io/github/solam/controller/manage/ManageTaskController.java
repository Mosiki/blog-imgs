package io.github.solam.controller.manage;

import com.alibaba.fastjson.JSONObject;
import io.github.solam.domain.Site;
import io.github.solam.dto.TaskDTO;
import io.github.solam.service.SiteService;
import io.github.solam.service.TaskService;
import io.github.solam.spider.WebMagicService;
import io.github.solam.spider.configmodel.TaskConfig;
import io.github.solam.spider.configmodel.WebMagicConfig;
import io.github.solam.util.ResultUtils;
import io.github.solam.vo.ResultVO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/task")
public class ManageTaskController {

    @Resource
    private TaskService taskService;
    @Resource
    private SiteService siteService;
    @Resource
    private WebMagicService webMagicService;

    @GetMapping(value = "/list")
    public ModelAndView list(Map<String, Object> map) {
        List<TaskDTO> list = taskService.findAll();
        map.put("tasks", list);
        return new ModelAndView("/manage/task/list", map);
    }

    @GetMapping(value = "/add")
    public ModelAndView add(Map<String, Object> map) {
        List<Site> all = siteService.findAll();
        map.put("list", all);
        return new ModelAndView("/manage/task/add", map);
    }

    @PostMapping(value = "/add")
    @ResponseBody
    public ResultVO add(TaskDTO taskDTO, Map<String, Object> map) {
        taskDTO = taskService.createTask(taskDTO);
        return ResultUtils.succss(taskDTO);
    }

    @PostMapping(value = "/del")
    @ResponseBody
    public ResultVO del(Long taskId) {
        TaskDTO taskDTO = taskService.delTask(taskId);
        return ResultUtils.succss(taskDTO);
    }

    @GetMapping(value = "/edit")
    public ModelAndView edit(Long taskId, Map<String, Object> map) {

        TaskDTO taskDTO = taskService.findOne(taskId);
        map.put("task", taskDTO);
        return new ModelAndView("/manage/task/edit", map);
    }

    @PostMapping(value = "/edit")
    @ResponseBody
    public ResultVO edit(TaskDTO taskDTO) {
        taskDTO = taskService.updateTask(taskDTO);
        return ResultUtils.succss(taskDTO);
    }

    @GetMapping(value = "/generate/rule")
    public ModelAndView toGenerate(Long taskId, Map<String, Object> map) {
        map.put("id", taskId);
        return new ModelAndView("/manage/task/rule", map);
    }

    @PostMapping(value = "/generate/rule")
    @ResponseBody
    public ResultVO generate(TaskConfig config) {
        // 传递三个参数   id(taskId) homeUrl bookUrl
//        JSONObject jsonObject = new JSONObject(params);
        webMagicService.generateRegex(config);
        return ResultUtils.succss(null);
    }

}
