package io.github.solam.spider.configmodel;

import lombok.Data;

import java.util.List;

@Data
public class RuleMatchConfig {

    private String bookXpath;
    private String bookRule;

    private String chapterXpath;
    private String chapterRule;

    private String bookIdRule;

    private List<DetailRuleConfig> bookInfoRule;

    private List<DetailRuleConfig> chapterContentRule;
}
