package io.github.solam.util.emums;

import lombok.Getter;

@Getter
public enum ResultEnum implements CodeEnum{

    TASK_NOT_EXIST(-100, "Task不存在!"),
    TASK_STATUS_ERROR(-101, "Task状态有误!"),
    SITE_NOT_EXIST(-102, "站点不存在!"),
    SUCCESS(1, "成功"),
    FAIL(-1, "失败"),
    BOOK_NOT_EXIST(-500, "作品不存在"),


    /** 格式校验  从-10001 开始 */
    MOBILE_ERROR(-1001, "手机号格式不正确"),
    MOBILE_CODE_FREQUENTLY(-1002, "验证码发送太过频繁，请稍后再试"),
    ;

    private Integer code;

    private String message;

    ResultEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

}
