package io.github.solam.service.impl;

import io.github.solam.exception.SolamException;
import io.github.solam.service.MobileService;
import io.github.solam.service.RedisService;
import io.github.solam.util.ValiationUtils;
import io.github.solam.util.WordUtil;
import io.github.solam.util.constants.CacheConstants;
import io.github.solam.util.emums.JedisPrefixTypeEnum;
import io.github.solam.util.emums.ResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class MobileServiceImpl implements MobileService {

//    @Autowired
//    private RedisService redisService;

    @Override
    public void sendCode(String mobile) {
        // 校验手机号是否合法
        if (!ValiationUtils.checkMobile(mobile)) {
            throw new SolamException(ResultEnum.MOBILE_ERROR);
        }

        // 校验手机号是否在黑名单中或者是否发送地太过频繁
        if (!allowSendCode(mobile)) {
            throw new SolamException(ResultEnum.MOBILE_CODE_FREQUENTLY);
        }

        // 控制发送频率
        String random = RandomStringUtils.random(4, "0123456789");
        //放到缓存
        long sendTime = System.currentTimeMillis();
        String value = random + CacheConstants.SEPARATOR + sendTime;
//        redisService.set(JedisPrefixTypeEnum.MOBILE_CODE, mobile, value, CacheConstants.CODE_TIME);

        // 4. 发送验证码，保存在 Redis 中，设置有效期
        String content = "您的验证码是: " + random + "，请在10分钟内完成验证，如非本人操作请忽略此消息。【Test】";
        log.info(content);
    }

    private boolean allowSendCode(String mobile) {
//        String value = redisService.get(JedisPrefixTypeEnum.MOBILE_CODE, mobile);
//        if (StringUtils.isNotEmpty(value)) {
//            long time = WordUtil.str2Long(value.split(CacheConstants.SEPARATOR)[1]);
//            if (System.currentTimeMillis() - time <= CacheConstants.SEND_FREQUENCY) {
//                return false;
//            }
//        }
        return true;
    }
}
