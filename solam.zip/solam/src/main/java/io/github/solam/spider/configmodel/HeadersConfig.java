package io.github.solam.spider.configmodel;

import lombok.Data;

@Data
public class HeadersConfig {

    private String name;

    private String value;
}
