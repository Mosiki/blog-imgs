package io.github.solam.dto;

import io.github.solam.util.WordUtil;
import io.github.solam.util.constants.Constants;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
public class BookDTO {
    private static final String ICON_PREFIX = Constants.QCLOUD_DOMAIN + Constants.ICON_PROFIX;

    private Long id;

    private String name;

    private String author;

    private String intro;

    private Integer icon;

    private Date createTime;

    private Date updateTime;

    private Byte status;

    public String getIconImg() {

        if ("0".equals(icon)) {
            return ICON_PREFIX + "0.jpg";
        } else {
            return ICON_PREFIX + id + ".jpg";
        }
    }

    public String getIntro() {
        return WordUtil.addP(intro);
    }
}
