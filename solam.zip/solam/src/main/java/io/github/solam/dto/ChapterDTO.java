package io.github.solam.dto;

import lombok.Data;

import java.util.Date;
@Data
public class ChapterDTO {

    private Long id;

    private Long bookId;

    private String name;

//    private Long contentId;
    private String content;

    private Date createTime;

    private Date updateTime;

    private Integer seq;

    private Byte status;
}
