package io.github.solam.service;

import io.github.solam.domain.ThirdBook;
import io.github.solam.domain.ThirdBookPK;

public interface ThirdBookService {

    ThirdBook add(ThirdBook thirdBook);

    ThirdBook get(ThirdBookPK id);

    ThirdBook update(ThirdBook resultThirdBook);
}
