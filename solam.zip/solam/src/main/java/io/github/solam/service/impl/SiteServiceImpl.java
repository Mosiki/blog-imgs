package io.github.solam.service.impl;

import io.github.solam.domain.Site;
import io.github.solam.exception.SolamException;
import io.github.solam.repository.SiteRepository;
import io.github.solam.service.SiteService;
import io.github.solam.util.constants.Constants;
import io.github.solam.util.emums.ResultEnum;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class SiteServiceImpl implements SiteService {

    @Resource
    private SiteRepository siteRepository;

    @Override
    public Page<Site> findList(Pageable pageable) {
        return siteRepository.findAll(pageable);
    }

    @Override
    public List<Site> findAll() {
        return siteRepository.findAll();
    }

    @Override
    public Site createSite(Site site) {
        site.setCreateTime(new Date());
        site.setStatus(Constants.STATUS_NORMAL);
        return siteRepository.save(site);
    }


    @Override
    public Site findOne(Long id) {
        return siteRepository.findOne(id);
    }

    @Override
    public Site updateSite(Site site) {
        Site result = siteRepository.findOne(site.getId());
        if (result == null) {
            throw new SolamException(ResultEnum.SITE_NOT_EXIST);
        }
        result.setSiteName(site.getSiteName());
        result.setSiteHome(site.getSiteHome());
        return siteRepository.save(result);
    }

    @Override
    public Site delSite(Long id) {
        Site site = siteRepository.findOne(id);
        if (Constants.STATUS_DELETE.equals(site.getStatus())) {
            throw new SolamException(ResultEnum.SITE_NOT_EXIST);
        }
        site.setStatus(Constants.STATUS_DELETE);
        return siteRepository.save(site);
    }
}
