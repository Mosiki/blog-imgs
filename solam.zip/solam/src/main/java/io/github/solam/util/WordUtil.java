package io.github.solam.util;

public class WordUtil {

    public static String addP(String str) {
        if (str == null || "".equals(str.trim()))
            return str;
        str = str.replaceAll("  ", "\n");
        String st[] = str.split("\n");
        StringBuffer sb = new StringBuffer();
        for (String s : st) {
            sb.append("<p>");
            sb.append(s);
            sb.append("</p>");
        }
        return sb.toString();
    }

    public static long str2Long(String str){
        long i = 0;
        if (str == null) {
            return 0;
        } else {

            try {
                i = Long.parseLong(str);
            } catch (Exception e) {
                return -1;
            }
        }
        return i;
    }
}
