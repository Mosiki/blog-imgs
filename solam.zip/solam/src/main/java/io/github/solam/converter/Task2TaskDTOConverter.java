package io.github.solam.converter;

import io.github.solam.domain.Task;
import io.github.solam.dto.TaskDTO;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.stream.Collectors;

public class Task2TaskDTOConverter {

    public static TaskDTO conver(Task task) {
        TaskDTO dto = new TaskDTO();
        BeanUtils.copyProperties(task, dto);
        return dto;
    }

    public static List<TaskDTO> conver(List<Task> list) {
        List<TaskDTO> collect = list.stream().map(e -> conver(e)).collect(Collectors.toList());
        return collect;
    }

    public static Task conver(TaskDTO taskDTO) {
        Task task = new Task();
        BeanUtils.copyProperties(taskDTO, task);
        return task;
    }
}
