package io.github.solam.domain;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "book")
public class Book {

    /** 主键id */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "name",columnDefinition = "NVARCHAR(20) COMMENT '作品名称'")
    private String name;

    @Column(name = "author",columnDefinition = "NVARCHAR(20) COMMENT '作品作者'")
    private String author;

    @Column(name = "intro",columnDefinition = "NVARCHAR(20) COMMENT '作品简介'")
    private String intro;

    @Column(name = "icon",columnDefinition = "int(11) COMMENT '作品封面'")
    private Integer icon;

    @Column(name = "create_time",columnDefinition = "datetime COMMENT '创建时间'")
    private Date createTime;

    @Column(name = "update_time",columnDefinition = "datetime COMMENT '修改时间'")
    private Date updateTime;

    private Byte status;
}
