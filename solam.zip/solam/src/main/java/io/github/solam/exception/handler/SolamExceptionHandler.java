package io.github.solam.exception.handler;

import io.github.solam.exception.SolamException;
import io.github.solam.util.ResultUtils;
import io.github.solam.vo.ResultVO;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class SolamExceptionHandler {

    @ExceptionHandler(SolamException.class)
    @ResponseBody
    public ResultVO handlerSolamExceptionHandler(SolamException e) {
        return ResultUtils.error(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public ResultVO handlerExceptionHandler(Exception e) {
        return ResultUtils.error(e.getMessage());
    }
}
