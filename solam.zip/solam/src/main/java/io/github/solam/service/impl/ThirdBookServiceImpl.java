package io.github.solam.service.impl;

import io.github.solam.domain.ThirdBook;
import io.github.solam.domain.ThirdBookPK;
import io.github.solam.repository.ThirdBookRepository;
import io.github.solam.service.ThirdBookService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;

@Service
public class ThirdBookServiceImpl implements ThirdBookService{

    @Resource
    private ThirdBookRepository thirdBookRepository;

    @Override
    public ThirdBook add(ThirdBook thirdBook) {
        thirdBook.setCreateTime(new Date());
        return thirdBookRepository.save(thirdBook);
    }

    @Override
    public ThirdBook get(ThirdBookPK id) {
        return thirdBookRepository.findOne(id);
    }

    @Override
    public ThirdBook update(ThirdBook resultThirdBook) {
        return thirdBookRepository.save(resultThirdBook);
    }
}
