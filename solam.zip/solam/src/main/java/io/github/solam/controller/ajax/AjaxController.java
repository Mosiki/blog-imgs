package io.github.solam.controller.ajax;

import io.github.solam.service.MobileService;
import io.github.solam.util.ResultUtils;
import io.github.solam.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/ajax")
public class AjaxController {

    @Autowired
    private MobileService mobileService;

    @GetMapping(value = "/sendCode")
    @ResponseBody
    public ResultVO sendCode(String phone) {

        mobileService.sendCode(phone);
        return ResultUtils.succss(null);
    }

}
