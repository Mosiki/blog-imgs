package io.github.solam.service;

public interface QcloudService {

    String uploadFile(String key, String value);

    String uploadUrlImage(String key, String imgUrl);

    String downloadFile(String key);
}
