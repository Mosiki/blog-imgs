package io.github.solam.spider;

import com.alibaba.fastjson.JSONObject;
import io.github.solam.dto.TaskDTO;
import io.github.solam.service.TaskService;
import io.github.solam.spider.configmodel.SpiderConfig;
import io.github.solam.spider.configmodel.TaskConfig;
import io.github.solam.spider.configmodel.WebMagicConfig;
import io.github.solam.spider.monitor.MySpiderMonitor;
import io.github.solam.spider.monitor.MySpiderStatus;
import io.github.solam.spider.pipe.SitePipeline;
import io.github.solam.spider.process.AbstractPageProcess;
import io.github.solam.spider.process.SitePageProcess;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import us.codecraft.webmagic.Request;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.pipeline.Pipeline;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class WebMagicService {

    @Resource
    private ApplicationContext context;
    @Resource
    private TaskService taskService;

    public void run(TaskDTO taskDTO, boolean runAsync) throws Exception {
        MySpiderMonitor spiderMonitor = MySpiderMonitor.instance();
        String ruleJson = taskDTO.getTaskRuleJson();
        WebMagicConfig config = JSONObject.parseObject(ruleJson, WebMagicConfig.class);
        SpiderConfig spiderConfig = config.getSpider();
        AbstractPageProcess pageProcess = context.getBean(spiderConfig.getProcesser(), AbstractPageProcess.class);

        pageProcess.init(config);
        pageProcess.setUuid(taskDTO.getSpiderUUID());

        Spider spider = Spider.create(pageProcess).thread(spiderConfig.getThread());
        spider.setUUID(taskDTO.getSpiderUUID());

        List<String> pipelines = spiderConfig.getPipeline();
        for (String pipeline : pipelines) {
            Pipeline bean = context.getBean(pipeline, Pipeline.class);
            if (bean != null) {
                spider.addPipeline(bean);
            }
        }
        // 设置Downloader
        // 设置Scheduler

        // 注册爬虫
        spiderMonitor.register(spider);
        spider.addUrl(spiderConfig.getStartUrl());

        if (runAsync) {
            spider.runAsync();
        } else {
            spider.run();
        }
    }

    /**
     * 爬虫状态监控
     * @return
     */
    public List<TaskDTO> runTaskList() {

        MySpiderMonitor spiderMonitor = MySpiderMonitor.instance();
        Map<String, MySpiderStatus> spiderStatuses = spiderMonitor.getSpiderStatuses();

        List<TaskDTO> taskDTOList = taskService.findAll();
        for (TaskDTO taskDTO : taskDTOList) {
            MySpiderStatus spiderStatus = spiderStatuses.get(taskDTO.getSpiderUUID());
            if (spiderStatus == null) {
                taskDTO.setRunState(Spider.Status.Stopped.name());
            } else {
                taskDTO.setRunState(spiderStatus.getStatus());
            }
        }

        return taskDTOList;
    }

    public TaskDTO stop(TaskDTO taskDTO) {
        MySpiderMonitor spiderMonitor = MySpiderMonitor.instance();
        Map<String, MySpiderStatus> spiderStatuses = spiderMonitor.getSpiderStatuses();
        MySpiderStatus spiderStatus = spiderStatuses.get(taskDTO.getSpiderUUID());

        if (spiderStatus != null) {
            spiderStatus.stop();
            spiderStatus.getSpider().close();
        }

        return taskDTO;
    }

    /**
     * 生成抓取正则
     * @param config
     */
    public void generateRegex(TaskConfig config) {
        Request request = new Request(config.getHomeUrl());
        request.putExtra("config", JSONObject.toJSONString(config));
        Spider.create(context.getBean("sitePageProcess", SitePageProcess.class))
                .addRequest(request)
                .addPipeline(context.getBean("sitePipeline", SitePipeline.class))
                .thread(1).run();

    }

}