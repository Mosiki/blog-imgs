package io.github.solam.service.impl;

import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.request.GetFileLocalRequest;
import com.qcloud.cos.request.UploadFileRequest;
import com.qcloud.cos.sign.Credentials;
import io.github.solam.exception.SolamException;
import io.github.solam.service.QcloudService;
import io.github.solam.util.constants.Constants;
import io.github.solam.util.emums.ResultEnum;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

@Service
public class QcloudServiceImpl implements QcloudService{

    private static COSClient cosClient;
    private static String bucketName;

    @Value(value = "${appId}")
    private Long appId;
    @Value(value = "${secretId}")
    private String secretId;
    @Value(value = "${secretKey}")
    private String secretKey;

    @PostConstruct
    public void init() {
        // 初始化秘钥信息
        Credentials cred = new Credentials(appId, secretId, secretKey);

        // 初始化客户端配置
        ClientConfig clientConfig = new ClientConfig();
        // 设置bucket所在的区域，比如华南园区：gz； 华北园区：tj；华东园区：sh ；
        clientConfig.setRegion("bj");
        // 初始化cosClient
        cosClient = new COSClient(clientConfig, cred);

        bucketName = "spider";
    }

    @PreDestroy
    public void shutdown() {
        if (cosClient != null) {
            cosClient.shutdown();
            System.out.println("shutdown.............");
        }
    }


    @Override
    public String uploadFile(String key, String value) {
        UploadFileRequest request = new UploadFileRequest(bucketName, key, value.getBytes());
        return cosClient.uploadFile(request);
    }

    @Override
    public String uploadUrlImage(String key, String imgUrl) {

//        String path = "/temp";
//        File folder = new File(path);
//        if(!folder.exists())
//            folder.mkdirs();

        key = key + ".jpg";
        try {
            URL url = new URL(imgUrl);
            InputStream is = url.openStream();
            UploadFileRequest request = new UploadFileRequest(bucketName, key, IOUtils.toByteArray(is));
            is.close();
            return cosClient.uploadFile(request);
        } catch (Exception e) {
            e.printStackTrace();
            throw new SolamException(ResultEnum.FAIL);
        }
    }

    @Override
    public String downloadFile(String key) {

        try {
            URL url = new URL(Constants.QCLOUD_DOMAIN + key);
            InputStream is = url.openStream();
            BufferedReader tBufferedReader = new BufferedReader(new InputStreamReader(is));

            StringBuilder tStringBuffer = new StringBuilder();

            String sTempOneLine = "";

            while ((sTempOneLine = tBufferedReader.readLine()) != null){
                tStringBuffer.append(sTempOneLine);
            }
            return tStringBuffer.toString();

        } catch (Exception e) {
            e.printStackTrace();
            throw new SolamException(ResultEnum.FAIL);
        }

    }


}
