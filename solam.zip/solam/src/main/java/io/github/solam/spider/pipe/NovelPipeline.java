package io.github.solam.spider.pipe;

import com.alibaba.fastjson.JSONObject;
import io.github.solam.domain.Book;
import io.github.solam.service.BookService;
import io.github.solam.service.ChapterService;
import io.github.solam.spider.WebMagicService;
import io.github.solam.util.EnumUtils;
import io.github.solam.util.emums.ApiTypeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import us.codecraft.webmagic.ResultItems;
import us.codecraft.webmagic.Task;
import us.codecraft.webmagic.pipeline.Pipeline;

import javax.annotation.Resource;
import java.util.Map;

@Component
public class NovelPipeline implements Pipeline {
    @Resource
    private WebMagicService webMagicService;
    @Resource
    private BookService bookService;
    @Resource
    private ChapterService chapterService;

    @Override
    public void process(ResultItems resultItems, Task task) {

        if (!resultItems.isSkip()) {
//            Site site = task.getSite();
//            String uuid = task.getUUID();

            switch (EnumUtils.getEnumByCode(resultItems.get("type"), ApiTypeEnum.class)) {
                case BOOK_INFO:
                    bookInfoProcess(resultItems, task);
                    break;
                case CHAPTER_CONTENT:
                    chapterContentProcess(resultItems, task);
                    break;
                default:
                    break;
            }
        }
    }

    private void bookInfoProcess(ResultItems resultItems, Task task) {
//        Book  book = new Book();
//        book.setSiteBookId(resultItems.get("siteBookId"));
//        book.setName(resultItems.get("name"));
//        book.setSiteId(resultItems.get("siteId"));
//        book.setAuthor(resultItems.get("author"));
//        book.setIntro(resultItems.get("intro"));
//        book.setIcon(1);
//        bookService.add(book);
//        System.out.println(resultItems.get("bookId") + "--" + resultItems.get("name"));
    }

    private void chapterContentProcess(ResultItems resultItems, Task task) {

        Map<String, Object> all = resultItems.getAll();
        System.out.println(JSONObject.toJSONString(all));
    }
}
