package io.github.solam.controller.mobile;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/m/user")
public class UserController {

    @GetMapping(value = "/phonelogin")
    public ModelAndView phonelogin() {
        return new ModelAndView("/user/phonelogin");
    }

}
