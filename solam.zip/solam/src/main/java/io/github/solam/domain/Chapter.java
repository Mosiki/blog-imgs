package io.github.solam.domain;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "chapter")
public class Chapter {

    /** 主键id */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    /** 站点BookId */
    @Column(name = "book_id",columnDefinition = "bigint COMMENT 'site_book_id'")
    private Long bookId;

    @Column(name = "name",columnDefinition = "NVARCHAR(20) COMMENT '章节名称'")
    private String name;

    @Column(name = "content_id",columnDefinition = "bigint COMMENT '章节内容id'")
    private Long contentId;

    @Column(name = "create_time",columnDefinition = "datetime COMMENT '创建时间'")
    private Date createTime;

    @Column(name = "update_time",columnDefinition = "datetime COMMENT '修改时间'")
    private Date updateTime;

    @Column(name = "seq")
    private Integer seq;

    private Byte status;
}
