package io.github.solam.service.impl;

import io.github.solam.domain.Book;
import io.github.solam.repository.BookRepository;
import io.github.solam.service.BookService;
import io.github.solam.util.constants.Constants;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class BookServiceImpl implements BookService{

    @Resource
    private BookRepository bookRepository;

    @Override
    public Book add(Book book) {
        book.setCreateTime(new Date());
        book.setStatus(Constants.STATUS_NORMAL);
        return bookRepository.save(book);
    }

    @Override
    public Book update(Book book) {
        book.setUpdateTime(new Date());
        return bookRepository.save(book);
    }

    @Override
    public Page<Book> findList(Pageable pageable) {
        return bookRepository.findAll(pageable);
    }

    @Override
    public List<Book> findAll() {
        return bookRepository.findAll();
    }

    @Override
    public Book findOne(Long id) {
        return bookRepository.findOne(id);
    }

    @Override
    public void delSite(Long id) {
        bookRepository.delete(id);
    }
}
