package io.github.solam.spider.configmodel;

import lombok.Data;

import java.util.List;

@Data
public class SpiderConfig {

    private Long siteid;

    private Integer thread;

    private String processer;

    private List<String> pipeline;

    private String downloader;

    private String startUrl;
}
