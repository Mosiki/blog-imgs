package io.github.solam.spider.process;

import com.alibaba.fastjson.JSONObject;
import io.github.solam.spider.configmodel.TaskConfig;
import io.github.solam.spider.pipe.SitePipeline;
import io.github.solam.util.emums.ApiTypeEnum;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Request;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.selector.Html;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SitePageProcess implements PageProcessor{

    private static final String EXTRAS_KEY = "config";

    @Resource
    private ApplicationContext context;

    private Site site = Site.me().setCycleRetryTimes(5).setRetryTimes(5).setSleepTime(1000).setTimeOut(99999)
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36")
            .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .addHeader("Accept-Language", "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3")
            .setCharset("utf-8");

    @Override
    public Site getSite() {
        return site;
    }

    @Override
    public void process(Page page) {
        // 从起始页进来
//        WebMagicConfig config = super.getConfig();
        String pageUrl = page.getUrl().get();

//        RuleMatchConfig rule = config.getRule();
        Html html = page.getHtml();

        Object params = page.getRequest().getExtra(EXTRAS_KEY);
        TaskConfig taskConfig = JSONObject.parseObject((String) params, TaskConfig.class);

        if (taskConfig.getHomeUrl().equals(pageUrl)) {
            String urlRule = getUrlRule(page);

            // 只抓取一个链接
            page.putField("bookInfoRule", urlRule);
            page.putField("type", ApiTypeEnum.BOOK_INFO.getCode());
            page.putField("id", taskConfig.getId());
            Request request = new Request(taskConfig.getBookUrl());
            request.putExtra(EXTRAS_KEY, params);
            page.addTargetRequest(request);
            return;
        }

        if (taskConfig.getBookUrl().equals(pageUrl)) {
            String urlRule = getUrlRule(page);

            // 只抓取一个链接
            page.putField("chapterRule", urlRule);
            page.putField("type", ApiTypeEnum.CHAPTER_CONTENT.getCode());
            page.putField("id", taskConfig.getId());
//            Request request = new Request(page.getHtml().xpath("//*/a/@href").regex(urlRule).get());
//            request.putExtra("params", params);
//            page.addTargetRequest(request);
            return;
        }

    }

    private String getUrlRule(Page page) {
        // 获取当前页面所有的链接URL
        List<String> list = page.getHtml().xpath("//*/a/@href").all();

        // 得到当前页面数量最多的URL的正则规则
        List<String> list2 = list.stream().map(e -> e.replaceAll("\\d+", "\\\\d+"))
                .collect(Collectors.toList());

        HashMap<String, Integer> map = new HashMap<>();
        for (String item : list2) {
            Integer value = map.get(item);
            map.put(item, (value == null) ? 1 : value + 1);
        }

        // 升序比较器
        Comparator<Map.Entry<String, Integer>> valueComparator = new Comparator<Map.Entry<String,Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> o1,
                               Map.Entry<String, Integer> o2) {
                return o2.getValue()-o1.getValue();
            }
        };

        // map转换成list进行排序
        List<Map.Entry<String, Integer>> list3 = new ArrayList<Map.Entry<String,Integer>>(map.entrySet());
        // 排序
        Collections.sort(list3,valueComparator);
        // 所有作品地址。
//        List<String> list4 = page.getHtml().xpath("//*/a/@href").regex(list3.get(0).getKey()).all();
//        list4.forEach(e -> System.out.println(e));
        // 相对URL正则
        return list3.get(0).getKey();
    }
}
