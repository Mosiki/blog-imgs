package io.github.solam.controller.manage;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ManageIndexController {

    @GetMapping(value = "/")
    public String index() {
        return "/manage/index";
    }
}
