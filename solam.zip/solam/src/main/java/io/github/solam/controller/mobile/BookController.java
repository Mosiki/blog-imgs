package io.github.solam.controller.mobile;

import io.github.solam.converter.Book2BookDTOConverter;
import io.github.solam.domain.Book;
import io.github.solam.domain.Chapter;
import io.github.solam.dto.BookDTO;
import io.github.solam.dto.ChapterDTO;
import io.github.solam.exception.SolamException;
import io.github.solam.service.BookService;
import io.github.solam.service.ChapterService;
import io.github.solam.util.emums.ResultEnum;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.Map;

@Controller
@RequestMapping(value = "/book")
public class BookController {

    @Resource
    private BookService bookService;
    @Resource
    private ChapterService chapterService;

    @GetMapping(value = "/{bookId}")
    public ModelAndView book(@PathVariable(name = "bookId")Long bookId, Map<String, Object> map) {
        Book book = bookService.findOne(bookId);
        if (book == null) {
            throw new SolamException(ResultEnum.BOOK_NOT_EXIST);
        }

        BookDTO bookDTO = Book2BookDTOConverter.conver(book);
        map.put("book", bookDTO);
        return new ModelAndView("/book/detail", map);
    }

    @GetMapping(value = "/{bookId}/{chapterId}")
    public ModelAndView chapter(@PathVariable(name = "bookId")Long bookId,
                                @PathVariable(name = "chapterId")Long chapterId,
                                Map<String, Object> map) {
        Book book = bookService.findOne(bookId);
        if (book == null) {
            throw new SolamException(ResultEnum.BOOK_NOT_EXIST);
        }

        ChapterDTO chapter = null;
        if (0 == chapterId) {
            chapter = chapterService.findFirstChapter(bookId);
        } else {
            chapter = chapterService.getChapter(chapterId);
        }
        Chapter nextChapter = chapterService.getNextChapterId(chapter.getId());
        BookDTO bookDTO = Book2BookDTOConverter.conver(book);
        map.put("book", bookDTO);
        map.put("chapter", chapter);
        map.put("nextChapter", nextChapter);
        return new ModelAndView("/book/chapter", map);
    }
}
