package io.github.solam.domain;

import lombok.Data;

import javax.persistence.Column;
import java.io.Serializable;

@Data
public class ThirdBookPK implements Serializable{
    private static final long serialVersionUID = -126020695246463441L;

    /** 站点Id */
    @Column(name = "site_id",columnDefinition = "bigint COMMENT '站点Id'")
    private Long siteId;

    /** 站点BookId */
    @Column(name = "site_book_id",columnDefinition = "bigint COMMENT 'site_book_id'")
    private Long siteBookId;

}
