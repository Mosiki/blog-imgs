package io.github.solam.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValiationUtils {

    public static final String MOBILE = "^1(3|4|5|7|8)\\d{9}$";

    public static boolean matches(String str, String regex) {
        if (str == null)
            return false;
        str = str.trim();
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(str);
        boolean b = m.matches();
        return b;
    }

    public static boolean checkMobile(String mobile) {
        return ValiationUtils.matches(mobile, ValiationUtils.MOBILE);
    }
}
