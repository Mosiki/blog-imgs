package io.github.solam.spider.configmodel;

import lombok.Data;

@Data
public class TaskConfig {

    private Long id;

    private String homeUrl;

    private String bookUrl;
}
