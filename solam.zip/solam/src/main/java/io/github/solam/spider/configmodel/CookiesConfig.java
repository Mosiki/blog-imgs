package io.github.solam.spider.configmodel;

import lombok.Data;

@Data
public class CookiesConfig {

    private String name;

    private String value;

}
