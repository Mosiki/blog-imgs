package io.github.solam.spider.configmodel;

import lombok.Data;

@Data
public class DetailRuleConfig {
    private String name;

    private String reg;

    private String value;
}
