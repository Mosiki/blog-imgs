package io.github.solam.spider.configmodel;

public class WebMagicConfig {

    private SpiderConfig spiderConfig;

    private SiteConfig siteConfig;

    private RuleMatchConfig ruleMatchConfig;

    public SpiderConfig getSpider() {
        return spiderConfig;
    }

    public void setSpider(SpiderConfig spider) {
        this.spiderConfig = spider;
    }

    public SiteConfig getSite() {
        return siteConfig;
    }

    public void setSite(SiteConfig site) {
        this.siteConfig = site;
    }

    public RuleMatchConfig getRule() {
        return ruleMatchConfig;
    }

    public void setRule(RuleMatchConfig ruleMatchConfig) {
        this.ruleMatchConfig = ruleMatchConfig;
    }

}
