package io.github.mosiki;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WechatSimpleExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(WechatSimpleExampleApplication.class, args);
	}
}
