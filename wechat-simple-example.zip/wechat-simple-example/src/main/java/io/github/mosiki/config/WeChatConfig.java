package io.github.mosiki.config;

import io.github.mosiki.handler.ScanHandler;
import io.github.mosiki.handler.SubscribeHandler;
import io.github.mosiki.handler.UnsubscribeHandler;
import lombok.Getter;
import me.chanjar.weixin.mp.api.WxMpConfigStorage;
import me.chanjar.weixin.mp.api.WxMpInMemoryConfigStorage;
import me.chanjar.weixin.mp.api.WxMpMessageRouter;
import me.chanjar.weixin.mp.api.WxMpService;
import me.chanjar.weixin.mp.api.impl.WxMpServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

import static me.chanjar.weixin.common.api.WxConsts.*;

@Getter
@Component
public class WeChatConfig {

    @Resource
    private WechatProperties wechatProperties;
    @Autowired
    private UnsubscribeHandler unsubscribeHandler;
    @Autowired
    private SubscribeHandler subscribeHandler;
//    @Autowired
//    private ScanHandler scanHandler;

    @Bean
    public WxMpService wxMpService() {
        WxMpService wxMpService = new WxMpServiceImpl();
        wxMpService.setWxMpConfigStorage(wxMpConfigStorage());
        return wxMpService;
    }

    @Bean
    public WxMpConfigStorage wxMpConfigStorage() {
        WxMpInMemoryConfigStorage wxMpConfigStorage = new WxMpInMemoryConfigStorage();
        wxMpConfigStorage.setAppId(wechatProperties.getAppId());
        wxMpConfigStorage.setSecret(wechatProperties.getSeecret());
        wxMpConfigStorage.setToken(wechatProperties.getToken());
        return wxMpConfigStorage;
    }

    @Bean
    public WxMpMessageRouter wxMpMessageRouter() {
        WxMpMessageRouter newRouter = new WxMpMessageRouter(wxMpService());
        // 关注事件
        newRouter.rule().async(false).msgType(XmlMsgType.EVENT)
                .event(EventType.SUBSCRIBE).handler(this.getSubscribeHandler())
                .end();

        // 取消关注事件
        newRouter.rule().async(false).msgType(XmlMsgType.EVENT)
                .event(EventType.UNSUBSCRIBE)
                .handler(this.getUnsubscribeHandler()).end();

        // 扫码事件
//        newRouter.rule().async(false).msgType(XmlMsgType.EVENT)
//                .event(EventType.SCAN).handler(this.getScanHandler()).end();
        return newRouter;
    }
}
