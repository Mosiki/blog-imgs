package io.github.mosiki.service;

public interface WechatService {

    /**
     * 创建永久事件二维码
     * @param param 附加的参数
     * @param needShortUrl 是否转换为短链接
     * @return 微信二维码地址
     */
    String createQrCode(String param, boolean needShortUrl);

    /**
     * 创建临时事件二维码
     * @param param 附加的参数
     * @param expireSeconds 有效时间 单位为秒，最大2592000（即30天）
     * @param needShortUrl 是否转换为短链接
     * @return 微信二维码地址
     */
    String createTempQrCode(String param, Integer expireSeconds, boolean needShortUrl);
}
