package io.github.mosiki.util;

public class WechatUtil {


}
