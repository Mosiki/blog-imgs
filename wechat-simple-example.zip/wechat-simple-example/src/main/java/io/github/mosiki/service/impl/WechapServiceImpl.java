package io.github.mosiki.service.impl;

import io.github.mosiki.service.WechatService;
import me.chanjar.weixin.common.exception.WxErrorException;
import me.chanjar.weixin.mp.api.WxMpQrcodeService;
import me.chanjar.weixin.mp.api.WxMpService;
import me.chanjar.weixin.mp.bean.result.WxMpQrCodeTicket;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class WechapServiceImpl implements WechatService {

    @Resource
    private WxMpService wxMpService;

    @Override
    public String createQrCode(String param, boolean needShortUrl) {
        WxMpQrcodeService qrService = wxMpService.getQrcodeService();
        try {
            WxMpQrCodeTicket ticket = qrService.qrCodeCreateLastTicket(param);
            String url = qrService.qrCodePictureUrl(ticket.getTicket(), needShortUrl);
            return url;
        } catch (WxErrorException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String createTempQrCode(String param, Integer expireSeconds, boolean needShortUrl) {
        WxMpQrcodeService qrService = wxMpService.getQrcodeService();
        try {
            WxMpQrCodeTicket ticket = qrService.qrCodeCreateTmpTicket(param, expireSeconds);
            String url = qrService.qrCodePictureUrl(ticket.getTicket(), needShortUrl);
            return url;
        } catch (WxErrorException e) {
            e.printStackTrace();
        }

        return null;
    }

}
